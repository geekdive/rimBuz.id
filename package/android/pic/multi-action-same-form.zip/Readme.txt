Submitting the form to same page
Code from 
http://www.html-form-guide.com/blog/web-form/91/submit-form-multiple-scripts/

Code shared under LGPL3
(http://www.gnu.org/licenses/lgpl.html)